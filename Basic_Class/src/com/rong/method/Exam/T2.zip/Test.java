package com.rong.method.Exam.T2;

public class Test {
    public static void main(String[] args) {
        Dog dog=new Dog("旺财");
        dog.goPlay();
    }
}
