package com.rong.method.Exam.T2;

public abstract class Animal {
      String name;

    public Animal(String name) {
        this.name = name;
    }
    public Animal() {
    }
    public abstract void speak (String str);
}
