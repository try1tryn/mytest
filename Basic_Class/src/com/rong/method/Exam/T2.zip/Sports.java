package com.rong.method.Exam.T2;

public interface Sports {
    void swimming ();
}
